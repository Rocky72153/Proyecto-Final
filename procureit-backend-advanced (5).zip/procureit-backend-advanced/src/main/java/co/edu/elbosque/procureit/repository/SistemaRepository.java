package co.edu.elbosque.procureit.repository;

import co.edu.elbosque.procureit.entity.Sistema;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SistemaRepository extends JpaRepository<Sistema, Integer> {}
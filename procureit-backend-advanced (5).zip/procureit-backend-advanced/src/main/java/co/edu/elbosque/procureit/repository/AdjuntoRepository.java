package co.edu.elbosque.procureit.repository;

import co.edu.elbosque.procureit.entity.Adjunto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdjuntoRepository extends JpaRepository<Adjunto, Long> {}
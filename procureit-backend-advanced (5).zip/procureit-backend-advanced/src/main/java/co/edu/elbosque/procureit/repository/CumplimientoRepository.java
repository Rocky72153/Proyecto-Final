package co.edu.elbosque.procureit.repository;

import co.edu.elbosque.procureit.entity.Cumplimiento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CumplimientoRepository extends JpaRepository<Cumplimiento, Long> {}